#!/bin/bash
# ──────────────────────────────────────────────────────────────
# RegOS PDF Extraction Benchmark — Master Runner
# Docling vs GPT-4o Vision on Opa-Locka Code of Ordinances
#
# Works both natively and inside Docker container.
# Inside Docker: PDF is mounted at /data/, results at /benchmark/results/
# Native:        PDF is expected next to the benchmark/ folder
# ──────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Detect if running in Docker (PDF mounted at /data/)
if [ -f "/data/input.pdf" ]; then
    PDF="/data/input.pdf"
    RESULTS="/benchmark/results"
    echo "[Docker mode] PDF: /data/input.pdf"
elif [ -n "${PDF_PATH:-}" ]; then
    PDF="$PDF_PATH"
    RESULTS="$SCRIPT_DIR/results"
    echo "[Custom path] PDF: $PDF"
else
    PDF="$SCRIPT_DIR/../Opa-locka, FL Code of Ordinances.pdf"
    RESULTS="$SCRIPT_DIR/results"
    echo "[Native mode] PDF: $PDF"
fi

# Page ranges to test (5 content types × 2 pages each)
RANGES=("1-2" "100-101" "200-201" "500-501" "750-751")

echo "=============================================="
echo "RegOS PDF Extraction Benchmark"
echo "=============================================="
echo "PDF: $PDF"
echo "Ranges: ${RANGES[*]}"
echo ""

# ── Check dependencies ──
echo "[0/5] Checking dependencies..."
command -v pdftotext >/dev/null 2>&1 || { echo "❌ pdftotext not found. Install: brew install poppler"; exit 1; }
command -v pdfseparate >/dev/null 2>&1 || { echo "❌ pdfseparate not found. Install: brew install poppler"; exit 1; }
command -v pdfunite >/dev/null 2>&1 || { echo "❌ pdfunite not found. Install: brew install poppler"; exit 1; }
python3 -c "import docling" 2>/dev/null || { echo "❌ docling not found. Install: pip install docling"; exit 1; }
python3 -c "import openai" 2>/dev/null || { echo "❌ openai not found. Install: pip install openai"; exit 1; }
python3 -c "from pdf2image import convert_from_path" 2>/dev/null || { echo "❌ pdf2image not found. Install: pip install pdf2image Pillow"; exit 1; }
echo "✅ All dependencies found"

if [ -z "${OPENROUTER_API_KEY:-}" ]; then
    echo "⚠️  OPENROUTER_API_KEY not set — GPT-4o pipeline will be SKIPPED"
    echo "   Run with: -e OPENROUTER_API_KEY=sk-or-..."
    GPT4O_ENABLED=false
else
    echo "✅ OPENROUTER_API_KEY detected"
    GPT4O_ENABLED=true
fi
echo ""

# ── Setup directories ──
mkdir -p "$RESULTS"/{samples,baseline,docling_md,docling_json,gpt4o}

# ── Step 1: Extract sample PDFs ──
echo "[1/5] Extracting sample pages..."
for range in "${RANGES[@]}"; do
    FIRST=$(echo "$range" | cut -d- -f1)
    LAST=$(echo "$range" | cut -d- -f2)
    SAMPLE="$RESULTS/samples/sample_${range}.pdf"

    if [ -f "$SAMPLE" ]; then
        echo "  sample_${range}.pdf already exists, skipping"
        continue
    fi

    TMP_DIR=$(mktemp -d)
    for p in $(seq "$FIRST" "$LAST"); do
        pdfseparate -f "$p" -l "$p" "$PDF" "$TMP_DIR/p${p}.pdf"
    done
    pdfunite "$TMP_DIR"/p*.pdf "$SAMPLE"
    rm -rf "$TMP_DIR"
    echo "  ✅ sample_${range}.pdf"
done
echo ""

# ── Step 2: pdftotext baseline ──
echo "[2/5] Extracting pdftotext baseline..."
for range in "${RANGES[@]}"; do
    FIRST=$(echo "$range" | cut -d- -f1)
    LAST=$(echo "$range" | cut -d- -f2)
    OUT="$RESULTS/baseline/baseline_${range}.txt"

    if [ -f "$OUT" ]; then
        echo "  baseline_${range}.txt already exists, skipping"
        continue
    fi

    pdftotext -f "$FIRST" -l "$LAST" "$PDF" "$OUT"
    WORDS=$(wc -w < "$OUT" | tr -d ' ')
    echo "  ✅ baseline_${range}.txt ($WORDS words)"
done
echo ""

# ── Step 3: Docling extraction ──
echo "[3/5] Running Docling extraction..."
DOCLING_BIN=$(which docling 2>/dev/null || echo "docling")
for range in "${RANGES[@]}"; do
    SAMPLE="$RESULTS/samples/sample_${range}.pdf"
    MD_DIR="$RESULTS/docling_md/${range}"
    JSON_DIR="$RESULTS/docling_json/${range}"

    if [ -d "$MD_DIR" ] && [ "$(ls -A "$MD_DIR" 2>/dev/null)" ]; then
        echo "  docling_md/${range}/ already exists, skipping"
    else
        mkdir -p "$MD_DIR"
        echo -n "  Running Docling (md) on pages ${range}... "
        START=$(python3 -c "import time; print(time.time())")
        $DOCLING_BIN --from pdf --to md --no-ocr "$SAMPLE" --output "$MD_DIR" 2>/dev/null
        END=$(python3 -c "import time; print(time.time())")
        ELAPSED=$(python3 -c "print(f'{$END - $START:.1f}')")
        echo "✅ ${ELAPSED}s"
    fi

    if [ -d "$JSON_DIR" ] && [ "$(ls -A "$JSON_DIR" 2>/dev/null)" ]; then
        echo "  docling_json/${range}/ already exists, skipping"
    else
        mkdir -p "$JSON_DIR"
        echo -n "  Running Docling (json) on pages ${range}... "
        START=$(python3 -c "import time; print(time.time())")
        $DOCLING_BIN --from pdf --to json --no-ocr "$SAMPLE" --output "$JSON_DIR" 2>/dev/null
        END=$(python3 -c "import time; print(time.time())")
        ELAPSED=$(python3 -c "print(f'{$END - $START:.1f}')")
        echo "✅ ${ELAPSED}s"
    fi
done
echo ""

# ── Step 4: GPT-4o Vision extraction ──
if [ "$GPT4O_ENABLED" = true ]; then
    echo "[4/5] Running GPT-4o Vision extraction via OpenRouter..."
    python3 "$SCRIPT_DIR/benchmark_gpt4o.py"
else
    echo "[4/5] GPT-4o Vision SKIPPED (no OPENROUTER_API_KEY)"
fi
echo ""

# ── Step 5: Score and report ──
echo "[5/5] Scoring results and generating report..."
python3 "$SCRIPT_DIR/score_and_report.py"

echo ""
echo "=============================================="
echo "BENCHMARK COMPLETE"
echo "=============================================="
echo "Results: $RESULTS/"
echo "Report:  $RESULTS/benchmark_report.json"
