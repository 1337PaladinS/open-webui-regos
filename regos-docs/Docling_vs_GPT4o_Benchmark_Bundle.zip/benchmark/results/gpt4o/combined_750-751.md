```markdown
<!-- page-header: § 22-118 -->

## OPA-LOCKA LAND DEVELOPMENT CODE

(H) Hurricane shutters may remain up only during periods of weather emergencies issued by the National Weather Service for the area. During these weather emergency events shutters may be erected but shall not remain up for more than two (2) weeks after the proclaimed event has passed.

(I) Exterior color standards for all commercial, industrial, multifamily, duplex and single-family buildings, existing and current.

All commercial, industrial, multifamily, duplex and single-family buildings shall have a unified exterior color chosen from the city's color scheme chart. This general requirement and other requirements outlined in this ordinance shall apply to all buildings-and-structures, commercial, industrial, multifamily, duplex and single-family buildings within the corporate limits of the city (all commercial and industrial buildings, residential town homes, single-family residences and medium, moderate and high density multifamily residential districts such as apartment buildings).

A. When the areas involved forms an integral part of any established section of the city, the exterior color shall enhance rather than detract from the character of the surrounding commercial/industrial buildings or multifamily, duplex and single-family residences.

The color scheme is established, and all existing and current businesses and multifamily, duplex and single-family residences shall conform to the established color scheme chart, a copy of which is attached as exhibit A to the ordinance from which this chapter is derived.

(Ord. No. 16-06, § 2, 7-13-2016; Ord. No. 16-07, exh. A(22-118), 9-14-2016)

### Sec. 22-119. Temporary use.

A. Temporary uses and occupancies.

(1) Intent.

A temporary permit system is hereby established to ensure special examination, review, and findings by appropriate agents, agencies, or bodies of the city related to proposed temporary uses and occupancies within the city.

A temporary permit system is hereby established, to be administered by the city manager or designee, in order to provide special examination and review of temporary uses and occupancies by the appropriate departments of the city or related agencies.

Enforcement of this code shall be by city police enforcement, code enforcement or any other remedies as provided by law.

(2) Temporary occupancies in general.

(a) Temporary occupancies are those uses and occupancies within the city of limited duration that occur on private property, public property, or in a combination of public and private properties, that would require special review by the city. Temporary occupancies are those that are not expected to remain on a property for more than two (2) years. Such uses are associated with land development or ongoing construction. They include, but are not limited to, temporary office use in connection with land development or construction activity (i.e., construction offices or watchman quarters); temporary parking for construction crews in connection to land development, storage facilities for construction equipment and materials; sales or leasing offices for newly constructed projects; construction trailers, fences, temporary encroachments, etc.

(i) A temporary permit would not be required for a use or occupancy required by the city.

(ii) Where a temporary permit use is associated with land development or construction activity, such temporary permits authorizing construction related activities may only be authorized in

<!-- page-footer: CD22:118 -->
```


---

<!-- page-header: § 22-119 -->

## OPA-LOCKA LAND DEVELOPMENT CODE

### § 22-119

(a)  conjunction with an active building permit for the approved project. No temporary permits shall be issued for construction activity that is not associated with a building permit for an approved development project.

(b)  The limitation of two (2) year duration may be waived by an affirmative vote of the city commission, to permit more time for an individual use.

<!-- page-footer: LDR:118.1 -->