```markdown
<!-- page-header: § 2-654 -->

## OPA-LOCKA CODE

(27) Bankrupt sales and other distress sales: one hundred dollars ($100.00).

(28) Barber or beauty schools (see schools Class 183).

(29) Basic schedule for retail and wholesale merchants. Every person whose primary business is retail or wholesale and who is not otherwise classified in the business tax code.

    Number of employees:
    
    - One (1) to four (4): one hundred twenty-five dollars ($125.00).
    - Five (5) to nine (9): two hundred sixty-five dollars ($265.00).
    - Ten (10) to nineteen (19): four hundred five dollars ($405.00).
    - Twenty (20) or more: five hundred forty-five dollars ($545.00).

Applicants under eighteen (18) years of age operating without a place of business must obtain city commission approval of location.

(38) Bottled water (see basic schedule Class 29).

(39) Bottling works or plant; same as manufacturers (see manufacturers Class 149).

(40) Boxing and wrestling.

    Promoter of: two hundred twenty-five dollars ($225.00).

(41) Brick, concrete or asphalt block manufacturers (see manufacturers Class 149).

(42) Brokers (see professional Class 173).

(43) Building and loan associations (see finance Class 91).

(44) Building material supply dealers (see basic schedule Class 29).

(45) Bureau of registry, nurses, teachers, etc. (see employment agency Class 84).

(46) Business office.

    Persons utilizing or renting office or desk space for a business not otherwise licensed:
    
    a. When operated solely by owner: fifty dollars ($50.00).
    b. Not more than three (3) employees: seventy-five dollars ($75.00).
    c. Four (4) and not more than five (5) employees: one hundred twenty dollars ($120.00).
    d. Six (6) and not more than fifteen (15) employees: one hundred fifty dollars ($150.00).
    e. Sixteen (16) and not more than twenty-five (25) employees: one hundred eighty-seven dollars and fifty cents ($187.50).
    f. Twenty-six (26) and not more than fifty (50) employees: two hundred twenty-five dollars ($225.00).
    g. For each additional fifty (50) or part thereof fifty (50): sixty-two dollars and fifty cents ($62.50).

(30) Baths (see health spa and/or swimming pool Class 110).

(31) Beauty parlors and barbershops.

    First chair: twenty-five dollars ($25.00).
    
    Each additional chair: twenty dollars ($20.00).

(32) Bicycles.

    a. Bicycle dealers; sale and rental (see basic schedule Class 29).
    b. Bicycle repairs (see repair and service Class 178).

(33) Blacksmith or horseshoer (see repair shops Class 178).

(34) Blueprinting or similar reproduction service (see repair and service Class 178).

(35) Boats (see repair and service Class 178 or automobile sales Class 23).

(36) Booking agent or agency: one hundred fifty dollars ($150.00).

(37) Bootblack (shoeshine).

    First chair: twelve dollars and fifty cents ($12.50).
    
    Each additional chair: two dollars and fifty cents ($2.50).

<!-- page-footer: CD2:132 -->
```

---

<!-- page-header: § 2-654 -->

## ADMINISTRATION

### Sec. 2-654

(47) Bus lines, office and station.  
(Additional license required for restaurants, concessions, etc.), each: two hundred twenty-five dollars ($225.00).

(48) Cabinet maker or carpenter shop (see manufacturer Class 149).

(49) Candy or confectionery shop.
   a. Fixed location (see basic schedule Class 29).
   b. Portable (see peddlers Class 167).

(50) Canvasser: one hundred dollars ($100.00).

(51) Carnival (see amusement Class 13).

(52) Carpet and rug cleaning (see repair and service Class 178).

(53) Caterer or catering service.
   a. Each company: one hundred eighty-seven dollars and fifty cents ($187.50).

Restaurants require separate license.
   b. Mobile vendors, lunch stand, portable or movable, each vehicle or stand (see peddlers Class 167).

(54) Cattle—Dealer in livestock.  
Per year or any fraction thereof: one hundred dollars ($100.00).  
Itinerant: two hundred dollars ($200.00).

(55) Cemetery salesman.  
Each: $30.00.

(56) Clairvoyant (see spiritualist mediums Class 193).

(57) Cleaners and drying agencies (see laundries Class 136).

(58) Clipping bureau (see business office Class 46).

(59) Clubs: two hundred fifty dollars ($250.00)
   a. Social. Licensee and principals shall be subject to a satisfactory police investigation to include fingerprints, photograph and FBI check. Separate business tax required for dancing where an admission charge is required and for dancing lessons for which a fee is charged and other categories listed in this chapter in which the club may engage. State-chartered nonprofit organizations are exempt from this subsection.
   b. Other. A license is required for each category in which the club engages, i.e., restaurant, dancing, golf course, etc. There shall be no license fee in those instances wherein the club does not engage in any commercial endeavor or where the membership dues/fees are not used for profit or gain.

(60) Coffee roaster, processor, or spice mills (see manufacturer Class 149).

(61) Coffee wagons (see peddlers Class 167).

(62) Cold storage warehouse (see storage and warehouse Class 194).

(63) Collection agency: one hundred twenty-five dollars ($125.00).

(64) Collection service.  
Industrial waste, refuse, rubbish (all applicants must be approved by the director of the department of public works and utilities).
   a. Industrial waste collectors: one hundred dollars ($100.00).  
   A five-thousand-dollar ($5,000.00) surety bond is required.
   b. Refuse and rubbish gatherer, each vehicle: fifty dollars ($50.00).

(65) Computer service (see electronic data processing Class 82).

(66) Contractors. A municipal contractor's license is required as well as all county license requirements.

(67) Convenience stores (see basic schedule Class 29).  
Where petroleum products are dispensed from pumps, a separate license is required.

(68) Credit associations; firms or corporations, or agents thereof, operating within the city supplying information for members and others: two hundred twenty-five dollars ($225.00).  
(Separate license for collection agency.)

<!-- page-footer: CD2:133 -->