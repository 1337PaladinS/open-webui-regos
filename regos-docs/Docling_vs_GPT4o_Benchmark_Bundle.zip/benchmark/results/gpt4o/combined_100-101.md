<!-- page-header: § 2-248 -->

## OPA-LOCKA CODE

### § 2-248

(f) Before submission of a waiver order the city manager shall require a written agreement from the employer in a similar form as set forth in the appendix C to this section, stating that: (a) the employer requires such nonresident workers for immediate employment, and the waiver of residency is sought for the purpose of building a labor service; (b) the employer is paying or intends to pay not less than the minimum wage to all employees in the same or related occupational classification as the nonresident workers; (c) the employer agrees to comply with minimum employment conditions or other pertinent matters consistent with the provisions of this division and such other applicable laws as the city manager or city commission may determine; and (d) such workers are guaranteed a workweek not to be less than forty (40) hours, except that a lesser workweek, not to be less than twenty (20) hours per week, shall be guaranteed nonresident workers in such industries and occupations as may be determined by the city manager except that any employer who has a bona fide labor union contract, as determined by the city manager and city attorney, under which the employer's workers are guaranteed full employment and such other benefits as the city manager may deem satisfactory shall not be required to guarantee any minimum workweek under the provision of this clause.

(g) The city manager shall provide nonresident workers covered by this division with a copy of the agreement required by subsection (c) of this section and with a certificate, the information on which shall be determined by the city manager and the city commission.

(h) If at any time subsequent to the employment of a nonresident worker pursuant to a waiver order, the city manager, upon notice to such officer or upon his own investigation, shall ascertain that there is available an occupationally qualified resident worker to fill the position of such nonresident worker, or if at any time the city manager finds, after investigation and hearing, that the public interest and welfare demand such action, the city manager shall notify the employer in writing and thereupon the employer shall, after giving the nonresident worker fourteen (14) days' notice of such fact, terminate the employment of the nonresident worker.

(i) A resident worker who has replaced a nonresident worker pursuant to the provisions of this division and whose services are contracted for without a definite term may not be discharged except for incompetence, insubordination, misconduct, violation of employers' rules and regulations or other just cause and shall not be replaced by the same or by any other nonresident worker unless so discharged and no other resident worker with the required skills is available.

(j) Any discharged resident worker who is aggrieved and believes his/her dismissal was without just cause may file a complaint with the personnel board within ten (10) working days following such dismissal and the personnel board shall cause an investigation to be made. If upon investigation the personnel board determines that a prima facie case of wrongful dismissal exists, she/he shall hold a hearing at which the employer and employee may introduce evidence to establish the facts. If it is the personnel board's determination that the worker was discharged in violation of the provisions set forth in this section, then the city manager shall order the reinstatement of the worker and the employer shall be ordered to pay the employee back pay from the date of dismissal to the date of reinstatement. The hearing and determination of the city manager shall be concluded not later than twenty (20) working days after the date of filing of the complaint.

(k) No employer shall reduce the regular workday or workweek of resident workers for the purpose of giving employment to nonresident workers.

(l) Any layoffs, by reasons of reduction in force, shall affect nonresident workers first. No resident worker shall be laid off while a nonresident worker is retained in the same occupational classification for which the resident

<!-- page-footer: CD2:42 -->

---

```markdown
<!-- page-header: § 2-250 -->

## Sec. 2-249. Enforcement and appeal.

(a) Enforcement.

(1) The city manager shall investigate all complaints involving violations of these regulations, and after notice and hearing issue an order disposing of the matter.

(2) The city manager shall petition any court of competent jurisdiction for the enforcement of an order issued under the provisions of this division, and the appropriate temporary relief or restraining order, and shall file in the court a transcript of the records in the proceedings, including where appropriate the pleading and testimony upon which the order was entered and the findings and order of the city manager. Upon such filing, the court shall cause notice to be served upon the person against whom the order is directed. Thereupon, the court shall have jurisdiction of the proceeding and may grant such temporary relief or restraining order as it shall deem just and proper, or issue a decree enforcing, modifying and enforcing as so modified, or setting aside in whole or in part the order of the city manager. In all such actions the city manager shall be represented by the city attorney and shall not be required to give bond as a condition to filing or maintaining any action for an injunction or restraining order.

(3) Any employer who willfully violates the provisions of this division or of any rules or regulations issued pursuant thereto shall be guilty of an offense. Each week or portion of week thereof during which an employer continues in willful violation shall constitute a separate offense.

(4) Injunctions. In addition to any other penalties prescribed by law, the city attorney may bring action in any court in the county to restrain violations of this division.

(b) Appeals. Anyone aggrieved by a decision or order of the city manager may appeal said decision to the city commission within ten (10) days following the date of the decision or order. The commencement of any proceedings in any court shall not operate as a stay of compliance with any provisions of this division or any rules, regulations or orders issued thereunder unless an injunction is entered by a court of competent jurisdiction. All findings, decisions or orders by the city manager as to questions of fact shall be deemed final if supported by substantial evidence.

(Code 1983, § 2-248; Ord. No. 95-6, § 5, 6-14-1995; Ord. No. 98-6, § 1, 7-22-1998)

## Sec. 2-250. Waiver.

(a) For the purposes of this division, a nonresident applicant or worker who meets the criteria, as set forth hereunder, shall receive an order of waiver from the personnel board to be approved by the city commission and submitted with his/her application for employment with Job Services of Florida or other local employment agencies. Residency requirements may be waived by the city manager and approved by the city commission if:

(1) By not hiring the nonresident applicant or retaining the nonresident worker, it would create an unreasonable hardship to the applicant/worker because of the employee's economic or personal family problems resulting from the relocation within the city limits;

<!-- page-footer: CD2:43 -->
```