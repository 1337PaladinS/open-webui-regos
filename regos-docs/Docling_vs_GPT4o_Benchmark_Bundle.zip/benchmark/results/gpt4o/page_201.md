<!-- page-header: § 2-654 -->

## ADMINISTRATION

### Sec. 2-654

(47) Bus lines, office and station.  
(Additional license required for restaurants, concessions, etc.), each: two hundred twenty-five dollars ($225.00).

(48) Cabinet maker or carpenter shop (see manufacturer Class 149).

(49) Candy or confectionery shop.
   a. Fixed location (see basic schedule Class 29).
   b. Portable (see peddlers Class 167).

(50) Canvasser: one hundred dollars ($100.00).

(51) Carnival (see amusement Class 13).

(52) Carpet and rug cleaning (see repair and service Class 178).

(53) Caterer or catering service.
   a. Each company: one hundred eighty-seven dollars and fifty cents ($187.50).

Restaurants require separate license.
   b. Mobile vendors, lunch stand, portable or movable, each vehicle or stand (see peddlers Class 167).

(54) Cattle—Dealer in livestock.  
Per year or any fraction thereof: one hundred dollars ($100.00).  
Itinerant: two hundred dollars ($200.00).

(55) Cemetery salesman.  
Each: $30.00.

(56) Clairvoyant (see spiritualist mediums Class 193).

(57) Cleaners and drying agencies (see laundries Class 136).

(58) Clipping bureau (see business office Class 46).

(59) Clubs: two hundred fifty dollars ($250.00)
   a. Social. Licensee and principals shall be subject to a satisfactory police investigation to include fingerprints, photograph and FBI check. Separate business tax required for dancing where an admission charge is required and for dancing lessons for which a fee is charged and other categories listed in this chapter in which the club may engage. State-chartered nonprofit organizations are exempt from this subsection.
   b. Other. A license is required for each category in which the club engages, i.e., restaurant, dancing, golf course, etc. There shall be no license fee in those instances wherein the club does not engage in any commercial endeavor or where the membership dues/fees are not used for profit or gain.

(60) Coffee roaster, processor, or spice mills (see manufacturer Class 149).

(61) Coffee wagons (see peddlers Class 167).

(62) Cold storage warehouse (see storage and warehouse Class 194).

(63) Collection agency: one hundred twenty-five dollars ($125.00).

(64) Collection service.  
Industrial waste, refuse, rubbish (all applicants must be approved by the director of the department of public works and utilities).
   a. Industrial waste collectors: one hundred dollars ($100.00).  
   A five-thousand-dollar ($5,000.00) surety bond is required.
   b. Refuse and rubbish gatherer, each vehicle: fifty dollars ($50.00).

(65) Computer service (see electronic data processing Class 82).

(66) Contractors. A municipal contractor's license is required as well as all county license requirements.

(67) Convenience stores (see basic schedule Class 29).  
Where petroleum products are dispensed from pumps, a separate license is required.

(68) Credit associations; firms or corporations, or agents thereof, operating within the city supplying information for members and others: two hundred twenty-five dollars ($225.00).  
(Separate license for collection agency.)

<!-- page-footer: CD2:133 -->