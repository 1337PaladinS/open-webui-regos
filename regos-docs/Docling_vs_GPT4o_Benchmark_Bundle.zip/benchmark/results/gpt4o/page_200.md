```markdown
<!-- page-header: § 2-654 -->

## OPA-LOCKA CODE

(27) Bankrupt sales and other distress sales: one hundred dollars ($100.00).

(28) Barber or beauty schools (see schools Class 183).

(29) Basic schedule for retail and wholesale merchants. Every person whose primary business is retail or wholesale and who is not otherwise classified in the business tax code.

    Number of employees:
    
    - One (1) to four (4): one hundred twenty-five dollars ($125.00).
    - Five (5) to nine (9): two hundred sixty-five dollars ($265.00).
    - Ten (10) to nineteen (19): four hundred five dollars ($405.00).
    - Twenty (20) or more: five hundred forty-five dollars ($545.00).

Applicants under eighteen (18) years of age operating without a place of business must obtain city commission approval of location.

(38) Bottled water (see basic schedule Class 29).

(39) Bottling works or plant; same as manufacturers (see manufacturers Class 149).

(40) Boxing and wrestling.

    Promoter of: two hundred twenty-five dollars ($225.00).

(41) Brick, concrete or asphalt block manufacturers (see manufacturers Class 149).

(42) Brokers (see professional Class 173).

(43) Building and loan associations (see finance Class 91).

(44) Building material supply dealers (see basic schedule Class 29).

(45) Bureau of registry, nurses, teachers, etc. (see employment agency Class 84).

(46) Business office.

    Persons utilizing or renting office or desk space for a business not otherwise licensed:
    
    a. When operated solely by owner: fifty dollars ($50.00).
    b. Not more than three (3) employees: seventy-five dollars ($75.00).
    c. Four (4) and not more than five (5) employees: one hundred twenty dollars ($120.00).
    d. Six (6) and not more than fifteen (15) employees: one hundred fifty dollars ($150.00).
    e. Sixteen (16) and not more than twenty-five (25) employees: one hundred eighty-seven dollars and fifty cents ($187.50).
    f. Twenty-six (26) and not more than fifty (50) employees: two hundred twenty-five dollars ($225.00).
    g. For each additional fifty (50) or part thereof fifty (50): sixty-two dollars and fifty cents ($62.50).

(30) Baths (see health spa and/or swimming pool Class 110).

(31) Beauty parlors and barbershops.

    First chair: twenty-five dollars ($25.00).
    
    Each additional chair: twenty dollars ($20.00).

(32) Bicycles.

    a. Bicycle dealers; sale and rental (see basic schedule Class 29).
    b. Bicycle repairs (see repair and service Class 178).

(33) Blacksmith or horseshoer (see repair shops Class 178).

(34) Blueprinting or similar reproduction service (see repair and service Class 178).

(35) Boats (see repair and service Class 178 or automobile sales Class 23).

(36) Booking agent or agency: one hundred fifty dollars ($150.00).

(37) Bootblack (shoeshine).

    First chair: twelve dollars and fifty cents ($12.50).
    
    Each additional chair: two dollars and fifty cents ($2.50).

<!-- page-footer: CD2:132 -->
```