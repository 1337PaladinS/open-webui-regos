```markdown
<!-- page-header: § 21-66 -->

## Sec. 21-66. Unauthorized connections.

Any unauthorized connections shall render the service subject to immediate discontinuance without notice and service will not be restored until such unauthorized connections have been removed and unless settlement is made in full for all water service estimated by the department to have been used by reason of such unauthorized connections.  
(Code 1955, § 23-15; Code 1983, § 21-66)

Secs. 21-67—21-76. Reserved.

## DIVISION 3. SERVICE RATES AND CHARGES*

### Sec. 21-77. Schedule of rates generally.

| Meter Size | 11/1/2015 | 10/1/2015 | 10/1/2016 | 10/1/2017 | 10/1/2018 |
|------------|-----------|-----------|-----------|-----------|-----------|
| ¾"         | $4.15     | $4.48     | $4.84     | $5.23     | $5.65     |
| 1"         | $23.78    | $25.68    | $27.73    | $29.95    | $32.35    |
| 1.5"       | $26.90    | $29.05    | $31.37    | $33.88    | $36.59    |
| 2"         | $55.06    | $59.46    | $64.22    | $69.36    | $74.91    |
| 3"         | $64.43    | $69.58    | $75.15    | $81.16    | $87.65    |
| 4"         | $81.95    | $88.51    | $95.59    | $103.24   | $111.50   |
| 6"         | $99.46    | $107.42   | $116.01   | $125.29   | $135.31   |
| 8"         | $116.86   | $126.21   | $136.31   | $147.21   | $158.99   |

Water usage rates per one thousand (1,000) gallons:

| Gallons     | 11/1/15 | 10/1/15 | 10/1/16 | 10/1/17 | 10/1/18 |
|-------------|---------|---------|---------|---------|---------|
| Residential |         |         |         |         |         |
| Block 1     | 1—5,000 | $2.74   | $2.96   | $3.20   | $3.46   | $3.74   |
| Block 2     | 5,001—10,000 | $3.43 | $3.70 | $4.00 | $4.32 | $4.67 |
| Block 3     | 10,001—15,000 | $11.15 | $12.04 | $13.00 | $14.04 | $15.16 |
| Block 4     | All Use 15,000 | $16.72 | $18.06 | $19.50 | $21.06 | $22.74 |

| Commercial  |         |         |         |         |         |
| Block 1     | All Use | $7.37   | $7.96   | $8.60   | $9.29   | $10.03  |

Sewer monthly service charge (residential and commercial):

| Meter Size | 11/1/2015 | 10/1/2015 | 10/1/2016 | 10/1/2017 | 10/1/2018 |
|------------|-----------|-----------|-----------|-----------|-----------|
| ¾"         | $4.15     | $4.48     | $4.84     | $5.23     | $5.65     |
| 1"         | $23.78    | $25.68    | $27.73    | $29.95    | $32.35    |
| 1.5"       | $26.90    | $29.05    | $31.37    | $33.88    | $36.59    |
| 2"         | $55.06    | $59.46    | $64.22    | $69.36    | $74.91    |
| 3"         | $64.43    | $69.58    | $75.15    | $81.16    | $87.65    |
| 4"         | $81.95    | $88.51    | $95.59    | $103.24   | $111.50   |
| 6"         | $99.46    | $107.42   | $116.01   | $125.29   | $135.31   |
| 8"         | $116.86   | $126.21   | $136.31   | $147.21   | $158.99   |

*County Code reference—Jurisdiction of county over municipal water rates, § 32-66.

<!-- page-footer: CD21:12 -->
```

---

<!-- page-header: § 21-80 -->

## WATER, SEWER AND STORMWATER UTILITIES

Sewer usage rate per one thousand (1,000) gallons:

| Gallons     | 1/1/2015 | 10/1/2015 | 10/1/2016 | 10/1/2017 | 10/1/2018 |
|-------------|----------|-----------|-----------|-----------|-----------|
| Residential |          |           |           |           |           |
| Block 1     | 1—5,000  | $4.47     | $4.83     | $5.22     | $5.64     | $6.09     |
| Block 2     | 5,001-10,000 | $6.38  | $6.89     | $7.44     | $8.04     | $8.68     |
| Block 3     | All Use 10,000 | $14.39 | $15.54 | $16.78    | $18.12    | $19.57    |
| Commercial  |          |           |           |           |           |
| Block 1     | All Use  | $10.53    | $11.37    | $12.28    | $13.26    | $14.32    |

Stormwater utility rate:

|             | 1/1/2015 | 10/1/2015 | 10/1/2016 | 10/1/2017 | 10/1/2018 |
|-------------|----------|-----------|-----------|-----------|-----------|
| Rate        | $4.00    | $6.00     | $9.00     | $12.00    | $15.50    |

**Fire hydrant service charges.** A fire hydrant service charge as specified in the city schedule of rates, fees and charges for water and sewer service, shall apply for all customers within the city's service area. This charge covers the cost of installation, replacement, repair and maintenance of fire hydrants, in addition to the cost of upgrading water mains to provide required fire flows. The charges are as follows:

| Water Meter Size (inches) | Charge Per Month |
|---------------------------|------------------|
| ¼                         | $1.00            |
| 1″                        | $5.00            |
| 1.5″                      | $7.00            |
| 2″                        | $10.00           |
| 3″                        | $12.00           |
| 4″                        | $15.00           |
| 6″                        | $20.00           |
| 8″                        | $25.00           |

(Code 1955, § 23-8; Code 1983, § 21-77; Ord. No. 80-2, § 1, 1-30-1980; Ord. No. 83-12, § 1, 12-14-1983; Ord. No. 84-12, § 1, 6-27-1984; Ord. No. 85-1, § 1, 1-9-1985; Ord. No. 85-15, § 1, 7-10-1985; Ord. No. 85-24, § 1, 10-9-1985; Ord. No. 87-8, § 1, 9-23-1987; Ord. No. 90-11, § 1, 9-26-1990; Ord. No. 91-18, § 1, 9-26-1991; Ord. No. 92-14, § 1, 9-23-1992; Ord. No. 01-1, § 1, 2-14-2001; Ord. No. 02-5, § 1, 1-3-2002; Ord. No. 08-03, §§ 2, 3, 4-9-2008; Ord. No. 09-16, § 2, 9-9-2009; Ord. No. 09-17, § 2, 9-21-2009; Ord. No. 09-20, § 2, 10-28-2009; Ord. No. 10-20, § 2, 7-28-2010; Ord. No. 14-17, § 2, 10-9-2014; Ord. No. 18-13, § 2, 9-26-2018)

### Sec. 21-78. Scope of minimum.

Every water supply service shall have a monthly minimum service charge on each service installed. This minimum monthly service charge shall be in accordance with the schedule in section 21-77, and shall entitle the consumer, without additional charge, to have supplied through the water meter the number of gallons of water set forth in the table in section 21-77. (Code 1955, § 23-8; Code 1983, § 21-78; Ord. No. 85-17, § 1, 7-10-1985)

### Sec. 21-79. Excess not charged against minimum for other months.

No excess consumption of water during one (1) month may be charged against the minimum allowance for any other month or months. (Code 1955, § 23-8; Code 1983, § 21-79)

### Sec. 21-80. Deposits.

There shall be deposited with the city, by each consumer of:

(a) Water and sewer service, water only service, or sewer only service:

| Water Meter Size (inches) | Residential Customers | Commercial Customers |
|---------------------------|-----------------------|----------------------|
| ¼                         | $170.00               | $250.00              |
| 1                         | $1,000.00             | $1,000.00            |
| 1 ½                       | $1,500.00             | $1,500.00            |
| 2                         | $2,000.00             | $2,000.00            |
| 3                         | $3,000.00             | $3,000.00            |
| 4                         | $4,000.00             | $4,000.00            |

<!-- page-footer: CD21:13 -->