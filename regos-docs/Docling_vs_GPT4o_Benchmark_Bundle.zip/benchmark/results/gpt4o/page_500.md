```markdown
<!-- page-header: § 21-66 -->

## Sec. 21-66. Unauthorized connections.

Any unauthorized connections shall render the service subject to immediate discontinuance without notice and service will not be restored until such unauthorized connections have been removed and unless settlement is made in full for all water service estimated by the department to have been used by reason of such unauthorized connections.  
(Code 1955, § 23-15; Code 1983, § 21-66)

Secs. 21-67—21-76. Reserved.

## DIVISION 3. SERVICE RATES AND CHARGES*

### Sec. 21-77. Schedule of rates generally.

| Meter Size | 11/1/2015 | 10/1/2015 | 10/1/2016 | 10/1/2017 | 10/1/2018 |
|------------|-----------|-----------|-----------|-----------|-----------|
| ¾"         | $4.15     | $4.48     | $4.84     | $5.23     | $5.65     |
| 1"         | $23.78    | $25.68    | $27.73    | $29.95    | $32.35    |
| 1.5"       | $26.90    | $29.05    | $31.37    | $33.88    | $36.59    |
| 2"         | $55.06    | $59.46    | $64.22    | $69.36    | $74.91    |
| 3"         | $64.43    | $69.58    | $75.15    | $81.16    | $87.65    |
| 4"         | $81.95    | $88.51    | $95.59    | $103.24   | $111.50   |
| 6"         | $99.46    | $107.42   | $116.01   | $125.29   | $135.31   |
| 8"         | $116.86   | $126.21   | $136.31   | $147.21   | $158.99   |

Water usage rates per one thousand (1,000) gallons:

| Gallons     | 11/1/15 | 10/1/15 | 10/1/16 | 10/1/17 | 10/1/18 |
|-------------|---------|---------|---------|---------|---------|
| Residential |         |         |         |         |         |
| Block 1     | 1—5,000 | $2.74   | $2.96   | $3.20   | $3.46   | $3.74   |
| Block 2     | 5,001—10,000 | $3.43 | $3.70 | $4.00 | $4.32 | $4.67 |
| Block 3     | 10,001—15,000 | $11.15 | $12.04 | $13.00 | $14.04 | $15.16 |
| Block 4     | All Use 15,000 | $16.72 | $18.06 | $19.50 | $21.06 | $22.74 |

| Commercial  |         |         |         |         |         |
| Block 1     | All Use | $7.37   | $7.96   | $8.60   | $9.29   | $10.03  |

Sewer monthly service charge (residential and commercial):

| Meter Size | 11/1/2015 | 10/1/2015 | 10/1/2016 | 10/1/2017 | 10/1/2018 |
|------------|-----------|-----------|-----------|-----------|-----------|
| ¾"         | $4.15     | $4.48     | $4.84     | $5.23     | $5.65     |
| 1"         | $23.78    | $25.68    | $27.73    | $29.95    | $32.35    |
| 1.5"       | $26.90    | $29.05    | $31.37    | $33.88    | $36.59    |
| 2"         | $55.06    | $59.46    | $64.22    | $69.36    | $74.91    |
| 3"         | $64.43    | $69.58    | $75.15    | $81.16    | $87.65    |
| 4"         | $81.95    | $88.51    | $95.59    | $103.24   | $111.50   |
| 6"         | $99.46    | $107.42   | $116.01   | $125.29   | $135.31   |
| 8"         | $116.86   | $126.21   | $136.31   | $147.21   | $158.99   |

*County Code reference—Jurisdiction of county over municipal water rates, § 32-66.

<!-- page-footer: CD21:12 -->
```