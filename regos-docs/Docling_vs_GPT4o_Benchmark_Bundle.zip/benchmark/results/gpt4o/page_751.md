<!-- page-header: § 22-119 -->

## OPA-LOCKA LAND DEVELOPMENT CODE

### § 22-119

(a)  conjunction with an active building permit for the approved project. No temporary permits shall be issued for construction activity that is not associated with a building permit for an approved development project.

(b)  The limitation of two (2) year duration may be waived by an affirmative vote of the city commission, to permit more time for an individual use.

<!-- page-footer: LDR:118.1 -->