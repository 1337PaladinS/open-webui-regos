```markdown
<!-- page-header: § 2-250 -->

## Sec. 2-249. Enforcement and appeal.

(a) Enforcement.

(1) The city manager shall investigate all complaints involving violations of these regulations, and after notice and hearing issue an order disposing of the matter.

(2) The city manager shall petition any court of competent jurisdiction for the enforcement of an order issued under the provisions of this division, and the appropriate temporary relief or restraining order, and shall file in the court a transcript of the records in the proceedings, including where appropriate the pleading and testimony upon which the order was entered and the findings and order of the city manager. Upon such filing, the court shall cause notice to be served upon the person against whom the order is directed. Thereupon, the court shall have jurisdiction of the proceeding and may grant such temporary relief or restraining order as it shall deem just and proper, or issue a decree enforcing, modifying and enforcing as so modified, or setting aside in whole or in part the order of the city manager. In all such actions the city manager shall be represented by the city attorney and shall not be required to give bond as a condition to filing or maintaining any action for an injunction or restraining order.

(3) Any employer who willfully violates the provisions of this division or of any rules or regulations issued pursuant thereto shall be guilty of an offense. Each week or portion of week thereof during which an employer continues in willful violation shall constitute a separate offense.

(4) Injunctions. In addition to any other penalties prescribed by law, the city attorney may bring action in any court in the county to restrain violations of this division.

(b) Appeals. Anyone aggrieved by a decision or order of the city manager may appeal said decision to the city commission within ten (10) days following the date of the decision or order. The commencement of any proceedings in any court shall not operate as a stay of compliance with any provisions of this division or any rules, regulations or orders issued thereunder unless an injunction is entered by a court of competent jurisdiction. All findings, decisions or orders by the city manager as to questions of fact shall be deemed final if supported by substantial evidence.

(Code 1983, § 2-248; Ord. No. 95-6, § 5, 6-14-1995; Ord. No. 98-6, § 1, 7-22-1998)

## Sec. 2-250. Waiver.

(a) For the purposes of this division, a nonresident applicant or worker who meets the criteria, as set forth hereunder, shall receive an order of waiver from the personnel board to be approved by the city commission and submitted with his/her application for employment with Job Services of Florida or other local employment agencies. Residency requirements may be waived by the city manager and approved by the city commission if:

(1) By not hiring the nonresident applicant or retaining the nonresident worker, it would create an unreasonable hardship to the applicant/worker because of the employee's economic or personal family problems resulting from the relocation within the city limits;

<!-- page-footer: CD2:43 -->
```