#!/bin/bash
# ──────────────────────────────────────────────────────
# RegOS PDF Benchmark — One-Command Docker Runner
# ──────────────────────────────────────────────────────
#
# Usage:
#   ./run.sh                           # Docling only
#   OPENROUTER_API_KEY=sk-or-... ./run.sh   # Docling + GPT-4o
#
# Results are saved to ./results/ (persists after container is removed)
# After benchmarking, clean up everything with:
#   ./run.sh clean
# ──────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# ── Clean mode ──
if [ "${1:-}" = "clean" ]; then
    echo "🧹 Cleaning up Docker resources..."
    docker compose down --rmi all --volumes 2>/dev/null || true
    echo "✅ Docker image and containers removed"
    echo "   Results in ./results/ are preserved (delete manually if needed)"
    exit 0
fi

# ── Verify PDF exists ──
PDF="../Opa-locka, FL Code of Ordinances.pdf"
if [ ! -f "$PDF" ]; then
    echo "❌ PDF not found: $PDF"
    echo "   Place 'Opa-locka, FL Code of Ordinances.pdf' in the parent directory"
    echo "   Or update the volume mount in docker-compose.yml"
    exit 1
fi

PAGE_COUNT=$(pdfinfo "$PDF" 2>/dev/null | grep "Pages:" | awk '{print $2}' || echo "unknown")
echo "=============================================="
echo "RegOS PDF Extraction Benchmark (Docker)"
echo "=============================================="
echo "PDF:    $(basename "$PDF") ($PAGE_COUNT pages)"
echo "GPT-4o: $([ -n "${OPENROUTER_API_KEY:-}" ] && echo "ENABLED (OpenRouter)" || echo "SKIPPED (no key)")"
echo ""

# ── Build + Run ──
echo "Building Docker image (first run downloads ~2GB for Docling models)..."
echo ""

if [ -n "${OPENROUTER_API_KEY:-}" ]; then
    OPENROUTER_API_KEY="$OPENROUTER_API_KEY" docker compose up --build --abort-on-container-exit
else
    docker compose up --build --abort-on-container-exit
fi

echo ""
echo "=============================================="
echo "DONE"
echo "=============================================="
echo "Results:  ./results/"
echo "Report:   ./results/benchmark_report.json"
echo "Docling:  ./results/docling_md/ & ./results/docling_json/"
echo "GPT-4o:   ./results/gpt4o/"
echo "Baseline: ./results/baseline/"
echo ""
echo "To clean up Docker (free disk space):"
echo "  ./run.sh clean"
