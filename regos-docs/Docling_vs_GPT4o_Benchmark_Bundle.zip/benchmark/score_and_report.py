#!/usr/bin/env python3
"""
Scoring engine for the PDF extraction benchmark.
Computes content recovery, structural fidelity, and GraphRAG chunk quality.
Generates benchmark_report.json with all metrics.
"""

import json
import re
import time
from collections import Counter
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
# Docker: results at /benchmark/results; Native: next to script
if Path("/benchmark/results").exists():
    RESULTS = Path("/benchmark/results")
else:
    RESULTS = SCRIPT_DIR / "results"
RANGES = ["1-2", "100-101", "200-201", "500-501", "750-751"]
TOTAL_DOC_PAGES = 948


# ─────────────────────────────────────────────
# Metric 1: Content Recovery (order-independent)
# ─────────────────────────────────────────────

def unigram_overlap(baseline: str, extracted: str) -> float:
    """Bag-of-words overlap. Order-independent."""
    if not baseline or not extracted:
        return 0.0
    base_words = set(baseline.lower().split())
    ext_words = set(extracted.lower().split())
    if not base_words:
        return 0.0
    return len(base_words & ext_words) / len(base_words)


def bigram_overlap(baseline: str, extracted: str) -> float:
    """Bigram overlap. Partially order-sensitive — catches garbled context."""
    def bigrams(text):
        words = text.lower().split()
        return set(zip(words, words[1:]))
    base_bg = bigrams(baseline)
    ext_bg = bigrams(extracted)
    if not base_bg:
        return 0.0
    return len(base_bg & ext_bg) / len(base_bg)


def char_recovery(baseline: str, extracted: str) -> float:
    """Character-level content recovery."""
    if not baseline:
        return 0.0
    base_chars = len(re.sub(r'\s+', '', baseline))
    ext_chars = len(re.sub(r'\s+', '', extracted))
    if base_chars == 0:
        return 0.0
    return min(ext_chars / base_chars, 1.5)  # Cap at 150% (allows some expansion)


# ─────────────────────────────────────────────
# Metric 2: Structural Fidelity
# ─────────────────────────────────────────────

def count_structure(text: str) -> dict:
    """Count structural elements in extracted text."""
    return {
        "section_numbers": len(re.findall(
            r'(?:Sec\.?\s*|§\s*)\d+-\d+(?:\.\d+)?', text
        )),
        "article_headers": len(re.findall(
            r'(?:ARTICLE|DIVISION)\s+[IVXLC0-9]+', text, re.IGNORECASE
        )),
        "subsection_labels": len(re.findall(
            r'\([a-z]\)|\(\d+\)|\([ivxlc]+\)', text
        )),
        "cross_references": len(re.findall(
            r'(?:pursuant to|as set forth in|under|per)\s+(?:section|§)\s*\d+',
            text, re.IGNORECASE
        )),
        "ordinance_citations": len(re.findall(
            r'Ord\.?\s*No\.?\s*\d+-\d+', text, re.IGNORECASE
        )),
        "dollar_amounts": len(re.findall(
            r'\$[\d,]+(?:\.\d{2})?', text
        )),
        "tables_detected": text.lower().count('|---') + text.lower().count('| ---'),
    }


def structural_fidelity_score(baseline_struct: dict, extracted_struct: dict) -> dict:
    """Score how well extracted structure matches baseline."""
    scores = {}
    for key in baseline_struct:
        expected = baseline_struct[key]
        actual = extracted_struct.get(key, 0)
        if expected == 0:
            scores[key] = {"expected": 0, "found": actual, "score": 1.0 if actual == 0 else 0.5}
        else:
            scores[key] = {
                "expected": expected,
                "found": actual,
                "score": round(min(actual / expected, 1.5), 3),  # Cap at 150%
            }
    # Weighted average
    weights = {
        "section_numbers": 3,
        "article_headers": 2,
        "subsection_labels": 2,
        "cross_references": 1,
        "ordinance_citations": 1,
        "dollar_amounts": 2,
        "tables_detected": 3,
    }
    total_weight = sum(weights.get(k, 1) for k in scores)
    weighted_sum = sum(scores[k]["score"] * weights.get(k, 1) for k in scores)
    scores["weighted_average"] = round(weighted_sum / total_weight, 3) if total_weight else 0
    return scores


# ─────────────────────────────────────────────
# Metric 3: GraphRAG Chunk Quality
# ─────────────────────────────────────────────

def chunk_by_sections(text: str) -> list:
    """Split text into chunks at section boundaries."""
    pattern = re.compile(
        r'(?=(?:###?\s+)?(?:Sec\.?\s*|§\s*)\d+-\d+)',
        re.MULTILINE
    )
    chunks = pattern.split(text)
    return [c.strip() for c in chunks if c.strip() and len(c.strip()) > 30]


def evaluate_chunks(chunks: list) -> dict:
    """Assess chunk quality for GraphRAG."""
    if not chunks:
        return {"count": 0, "avg_size": 0, "boundary_accuracy": 0, "size_variance": 0}

    sizes = [len(c) for c in chunks]
    # Check how many chunks start with a section number
    section_start = sum(
        1 for c in chunks
        if re.match(r'(?:###?\s+)?(?:Sec\.?\s*|§\s*)\d+-\d+', c.strip())
    )

    return {
        "count": len(chunks),
        "avg_size": round(sum(sizes) / len(sizes), 1),
        "min_size": min(sizes),
        "max_size": max(sizes),
        "boundary_accuracy": round(section_start / len(chunks), 3) if chunks else 0,
        "ideal_range_pct": round(
            sum(1 for s in sizes if 300 <= s <= 3000) / len(sizes), 3
        ),  # % of chunks in ideal 300-3000 char range
    }


# ─────────────────────────────────────────────
# Docling JSON structure analysis
# ─────────────────────────────────────────────

def analyze_docling_json(json_path: Path) -> dict:
    """Analyze Docling's JSON output for element-level metadata."""
    try:
        with open(json_path) as f:
            doc = json.load(f)
    except Exception:
        return {"error": "Could not parse JSON"}

    texts = doc.get("texts", [])
    tables = doc.get("tables", [])
    label_counts = Counter(t.get("label", "unknown") for t in texts)

    return {
        "total_elements": len(texts),
        "tables": len(tables),
        "element_types": dict(label_counts.most_common()),
        "has_section_headers": label_counts.get("section_header", 0) > 0,
        "has_list_items": label_counts.get("list_item", 0) > 0,
        "has_page_headers": label_counts.get("page_header", 0) > 0,
    }


# ─────────────────────────────────────────────
# CPU Normalisation
# ─────────────────────────────────────────────

def cpu_benchmark() -> float:
    """Single-threaded benchmark. Returns normalisation factor vs M2 Pro."""
    times = []
    for _ in range(3):
        start = time.perf_counter()
        total = 0
        for i in range(2_000_000):
            total += i * i % 997
        times.append(time.perf_counter() - start)
    median = sorted(times)[1]
    M2_PRO_BASELINE = 0.30
    return round(median / M2_PRO_BASELINE, 2)


# ─────────────────────────────────────────────
# Main scoring
# ─────────────────────────────────────────────

def main():
    print("  Computing CPU normalisation...")
    cpu_factor = cpu_benchmark()
    print(f"  CPU factor: {cpu_factor}x vs M2 Pro")

    report = {
        "metadata": {
            "document": "Opa-locka, FL Code of Ordinances",
            "total_pages": TOTAL_DOC_PAGES,
            "pages_benchmarked": 10,
            "ranges": RANGES,
            "cpu_normalisation_factor": cpu_factor,
            "timestamp": time.strftime("%Y-%m-%d %H:%M"),
        },
        "per_range": [],
        "aggregate": {},
    }

    # Check if GPT-4o results exist
    gpt4o_results_path = RESULTS / "gpt4o" / "gpt4o_results.json"
    gpt4o_data = None
    if gpt4o_results_path.exists():
        with open(gpt4o_results_path) as f:
            gpt4o_data = json.load(f)

    # Score each range
    for range_label in RANGES:
        print(f"  Scoring range {range_label}...")
        range_result = {"range": range_label}

        # Load baseline
        baseline_path = RESULTS / "baseline" / f"baseline_{range_label}.txt"
        baseline = baseline_path.read_text() if baseline_path.exists() else ""

        # Load Docling markdown
        docling_md_dir = RESULTS / "docling_md" / range_label
        docling_md_files = list(docling_md_dir.glob("*.md")) if docling_md_dir.exists() else []
        docling_md = docling_md_files[0].read_text() if docling_md_files else ""

        # Load Docling JSON
        docling_json_dir = RESULTS / "docling_json" / range_label
        docling_json_files = list(docling_json_dir.glob("*.json")) if docling_json_dir.exists() else []

        # Load GPT-4o combined output
        gpt4o_md_path = RESULTS / "gpt4o" / f"combined_{range_label}.md"
        gpt4o_md = gpt4o_md_path.read_text() if gpt4o_md_path.exists() else ""

        # ── Content Recovery ──
        range_result["content_recovery"] = {
            "docling": {
                "unigram_overlap": round(unigram_overlap(baseline, docling_md), 4),
                "bigram_overlap": round(bigram_overlap(baseline, docling_md), 4),
                "char_recovery": round(char_recovery(baseline, docling_md), 4),
            },
        }
        if gpt4o_md:
            range_result["content_recovery"]["gpt4o"] = {
                "unigram_overlap": round(unigram_overlap(baseline, gpt4o_md), 4),
                "bigram_overlap": round(bigram_overlap(baseline, gpt4o_md), 4),
                "char_recovery": round(char_recovery(baseline, gpt4o_md), 4),
            }

        # ── Structural Fidelity ──
        baseline_struct = count_structure(baseline)
        docling_struct = count_structure(docling_md)
        range_result["structural_fidelity"] = {
            "baseline": baseline_struct,
            "docling": structural_fidelity_score(baseline_struct, docling_struct),
        }
        if gpt4o_md:
            gpt4o_struct = count_structure(gpt4o_md)
            range_result["structural_fidelity"]["gpt4o"] = structural_fidelity_score(
                baseline_struct, gpt4o_struct
            )

        # ── Chunk Quality ──
        docling_chunks = chunk_by_sections(docling_md)
        range_result["chunk_quality"] = {
            "docling": evaluate_chunks(docling_chunks),
        }
        if gpt4o_md:
            gpt4o_chunks = chunk_by_sections(gpt4o_md)
            range_result["chunk_quality"]["gpt4o"] = evaluate_chunks(gpt4o_chunks)

        # ── Docling JSON Metadata ──
        if docling_json_files:
            range_result["docling_json_analysis"] = analyze_docling_json(docling_json_files[0])

        report["per_range"].append(range_result)

    # ── Aggregate scores ──
    n = len(report["per_range"])
    if n > 0:
        def avg(path_fn):
            vals = [path_fn(r) for r in report["per_range"] if path_fn(r) is not None]
            return round(sum(vals) / len(vals), 4) if vals else None

        report["aggregate"]["docling"] = {
            "avg_unigram_overlap": avg(lambda r: r["content_recovery"]["docling"]["unigram_overlap"]),
            "avg_bigram_overlap": avg(lambda r: r["content_recovery"]["docling"]["bigram_overlap"]),
            "avg_char_recovery": avg(lambda r: r["content_recovery"]["docling"]["char_recovery"]),
            "avg_structural_fidelity": avg(
                lambda r: r["structural_fidelity"]["docling"]["weighted_average"]
            ),
            "total_sections_found": sum(
                r["structural_fidelity"]["docling"].get("section_numbers", {}).get("found", 0)
                for r in report["per_range"]
            ),
            "cost_per_page": 0.0,
            "cost_full_doc": 0.0,
        }

        if gpt4o_data:
            report["aggregate"]["gpt4o"] = {
                "avg_unigram_overlap": avg(
                    lambda r: r["content_recovery"].get("gpt4o", {}).get("unigram_overlap")
                ),
                "avg_bigram_overlap": avg(
                    lambda r: r["content_recovery"].get("gpt4o", {}).get("bigram_overlap")
                ),
                "avg_char_recovery": avg(
                    lambda r: r["content_recovery"].get("gpt4o", {}).get("char_recovery")
                ),
                "avg_structural_fidelity": avg(
                    lambda r: r["structural_fidelity"].get("gpt4o", {}).get("weighted_average")
                ),
                "avg_time_per_page": gpt4o_data.get("avg_time_per_page_sec", 0),
                "cost_per_page": gpt4o_data.get("avg_cost_per_page_usd", 0),
                "cost_full_doc": round(
                    gpt4o_data.get("avg_cost_per_page_usd", 0) * TOTAL_DOC_PAGES, 2
                ),
            }

    # Save report
    report_path = RESULTS / "benchmark_report.json"
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    # ── Print summary ──
    print("\n  " + "=" * 64)
    print("  BENCHMARK SCORES")
    print("  " + "=" * 64)

    docling_agg = report["aggregate"].get("docling", {})
    gpt4o_agg = report["aggregate"].get("gpt4o", {})

    fmt = "  {:<36} {:>12} {:>12}"
    print(fmt.format("Metric", "Docling", "GPT-4o"))
    print("  " + "-" * 64)
    print(fmt.format("Unigram Overlap (content recovery)",
                     f"{docling_agg.get('avg_unigram_overlap', 'N/A')}",
                     f"{gpt4o_agg.get('avg_unigram_overlap', 'N/A')}"))
    print(fmt.format("Bigram Overlap (context fidelity)",
                     f"{docling_agg.get('avg_bigram_overlap', 'N/A')}",
                     f"{gpt4o_agg.get('avg_bigram_overlap', 'N/A')}"))
    print(fmt.format("Char Recovery",
                     f"{docling_agg.get('avg_char_recovery', 'N/A')}",
                     f"{gpt4o_agg.get('avg_char_recovery', 'N/A')}"))
    print(fmt.format("Structural Fidelity (weighted)",
                     f"{docling_agg.get('avg_structural_fidelity', 'N/A')}",
                     f"{gpt4o_agg.get('avg_structural_fidelity', 'N/A')}"))
    print(fmt.format("Cost/Page",
                     "$0.00",
                     f"${gpt4o_agg.get('cost_per_page', 'N/A')}"))
    print(fmt.format("Cost Full Doc (948 pages)",
                     "$0.00",
                     f"${gpt4o_agg.get('cost_full_doc', 'N/A')}"))
    print("  " + "=" * 64)
    print(f"\n  Full report: {report_path}")


if __name__ == "__main__":
    main()
