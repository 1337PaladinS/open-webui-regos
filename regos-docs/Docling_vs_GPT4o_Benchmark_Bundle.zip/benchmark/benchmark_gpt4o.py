#!/usr/bin/env python3
"""
GPT-4o Vision extraction pipeline via OpenRouter.
Processes each sample PDF page-by-page, saves raw responses + timing.
"""

import base64
import json
import os
import sys
import time
from io import BytesIO
from pathlib import Path

try:
    import openai
    from pdf2image import convert_from_path
except ImportError as e:
    print(f"Missing dependency: {e}")
    print("Install: pip install openai pdf2image Pillow")
    sys.exit(1)

SCRIPT_DIR = Path(__file__).parent
# Docker: results at /benchmark/results; Native: next to script
if Path("/benchmark/results").exists():
    RESULTS = Path("/benchmark/results")
else:
    RESULTS = SCRIPT_DIR / "results"
SAMPLES_DIR = RESULTS / "samples"
GPT4O_DIR = RESULTS / "gpt4o"
GPT4O_DIR.mkdir(parents=True, exist_ok=True)

OPENROUTER_KEY = os.environ.get("OPENROUTER_API_KEY", "")
if not OPENROUTER_KEY:
    print("ERROR: OPENROUTER_API_KEY environment variable not set")
    sys.exit(1)

client = openai.OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_KEY,
)

# Municipal-code-optimised extraction prompt
EXTRACTION_PROMPT = """Extract ALL text from this municipal code page verbatim. Output as structured markdown.

Rules:
1. Use ## for Article/Division headers, ### for Section headers (e.g., ### Sec. 21-66. Title here.)
2. Preserve ALL section numbers exactly as printed (§ 22-118, Sec. 21-66)
3. Preserve ALL subsection labels exactly: (a), (b), (1), (i), (ii)
4. Render tables as markdown tables with | delimiters and --- separator rows
5. Preserve ALL dollar amounts, dates, and numeric values exactly as printed
6. Preserve ALL ordinance citations (Ord. No. XX-XX, § X, date)
7. Preserve ALL cross-references ("pursuant to section X", "as set forth in Section Y")
8. Do NOT summarise, paraphrase, or skip any text — extract every word
9. Mark page headers with <!-- page-header: § XX-XX --> at the top
10. Mark page footers with <!-- page-footer: CDXX:XX --> at the bottom
11. For fee schedules and rate tables, use proper markdown table formatting
12. Preserve indentation levels for nested list items using markdown indent (4 spaces)"""


def process_page(img, page_num: int, range_label: str) -> dict:
    """Send a single page image to GPT-4o Vision and return the result."""
    # Convert PIL image to base64 PNG
    buf = BytesIO()
    img.save(buf, format="PNG", optimize=True)
    img_b64 = base64.b64encode(buf.getvalue()).decode()
    img_size_kb = len(buf.getvalue()) / 1024

    start = time.perf_counter()
    try:
        response = client.chat.completions.create(
            model="openai/gpt-4o",
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": EXTRACTION_PROMPT},
                    {"type": "image_url", "image_url": {
                        "url": f"data:image/png;base64,{img_b64}",
                        "detail": "high"
                    }}
                ]
            }],
            max_tokens=4096,
            temperature=0.0,
        )
        elapsed = time.perf_counter() - start

        text = response.choices[0].message.content or ""
        usage = response.usage
        input_tokens = usage.prompt_tokens if usage else 0
        output_tokens = usage.completion_tokens if usage else 0

        return {
            "page": page_num,
            "range": range_label,
            "text": text,
            "time_sec": round(elapsed, 2),
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "image_size_kb": round(img_size_kb, 1),
            "chars": len(text),
            "words": len(text.split()),
            "error": None,
        }

    except Exception as e:
        elapsed = time.perf_counter() - start
        return {
            "page": page_num,
            "range": range_label,
            "text": "",
            "time_sec": round(elapsed, 2),
            "input_tokens": 0,
            "output_tokens": 0,
            "image_size_kb": round(img_size_kb, 1),
            "chars": 0,
            "words": 0,
            "error": str(e),
        }


def main():
    ranges = ["1-2", "100-101", "200-201", "500-501", "750-751"]
    all_results = []
    total_cost = 0.0

    for range_label in ranges:
        sample_pdf = SAMPLES_DIR / f"sample_{range_label}.pdf"
        if not sample_pdf.exists():
            print(f"  ⚠️  {sample_pdf.name} not found, skipping")
            continue

        first = int(range_label.split("-")[0])
        print(f"  Processing pages {range_label}...")

        # Convert PDF pages to images
        images = convert_from_path(str(sample_pdf), dpi=200)

        for idx, img in enumerate(images):
            page_num = first + idx
            print(f"    Page {page_num}...", end=" ", flush=True)

            result = process_page(img, page_num, range_label)
            all_results.append(result)

            if result["error"]:
                print(f"❌ {result['error']}")
            else:
                # Estimate cost (OpenRouter GPT-4o pricing)
                page_cost = (result["input_tokens"] * 2.50 / 1_000_000) + \
                            (result["output_tokens"] * 10.00 / 1_000_000)
                total_cost += page_cost
                print(f"✅ {result['time_sec']}s | {result['chars']} chars | "
                      f"{result['input_tokens']}+{result['output_tokens']} tokens | ${page_cost:.4f}")

            # Save individual page markdown
            md_path = GPT4O_DIR / f"page_{page_num}.md"
            md_path.write_text(result["text"])

        # Save range combined markdown
        range_text = "\n\n---\n\n".join(
            r["text"] for r in all_results if r["range"] == range_label and r["text"]
        )
        (GPT4O_DIR / f"combined_{range_label}.md").write_text(range_text)

    # Save full results JSON
    summary = {
        "model": "openai/gpt-4o",
        "provider": "OpenRouter",
        "total_pages": len(all_results),
        "total_time_sec": round(sum(r["time_sec"] for r in all_results), 2),
        "total_input_tokens": sum(r["input_tokens"] for r in all_results),
        "total_output_tokens": sum(r["output_tokens"] for r in all_results),
        "total_cost_usd": round(total_cost, 4),
        "avg_time_per_page_sec": round(
            sum(r["time_sec"] for r in all_results) / max(len(all_results), 1), 2
        ),
        "avg_cost_per_page_usd": round(total_cost / max(len(all_results), 1), 5),
        "errors": sum(1 for r in all_results if r["error"]),
        "pages": all_results,
    }

    out_path = GPT4O_DIR / "gpt4o_results.json"
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)

    print(f"\n  Total cost: ${total_cost:.4f}")
    print(f"  Avg time/page: {summary['avg_time_per_page_sec']}s")
    print(f"  Results saved: {out_path}")


if __name__ == "__main__":
    main()
